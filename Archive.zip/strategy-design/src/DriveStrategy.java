
interface DriveStrategy {
    public void drive();    
}
