public class SpeedDriveStrategy implements DriveStrategy{
    @Override
    public void drive() {
        System.out.println("speed drive capability");
    }
    
}
