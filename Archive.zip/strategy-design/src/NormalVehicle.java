public class NormalVehicle extends Vehicle{

    public NormalVehicle() {
        super(new NormalDriveStrategy());
        //TODO Auto-generated constructor stub
    }
    
}
