
public class Card {
    String bankName, accountNumber, cvv;

    public Card(String bankName, String accountNumber, String cvv) {
        this.bankName = bankName;
        this.accountNumber = accountNumber;
        this.cvv = cvv;
    }

}
