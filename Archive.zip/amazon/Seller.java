import java.util.List;

public class Seller extends User{
    List<Product> productList;
    Address address;
    public Seller(String name,String id,String email){
        super(name, id, email);
    }   
    public void addProduct(){

    }
    public void removeProduct(){
        
    }
}
