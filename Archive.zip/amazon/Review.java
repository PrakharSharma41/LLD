import java.util.List;

public class Review {
    List<String>reviews;
}
