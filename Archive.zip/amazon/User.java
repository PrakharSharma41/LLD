class User{
    String name,id,email;

    public User(String name, String id, String email) {
        this.name = name;
        this.id = id;
        this.email = email;
    }
    
}