enum Category{
    ELECTRONICS,
    FASHION,
    SPORTS;
}
