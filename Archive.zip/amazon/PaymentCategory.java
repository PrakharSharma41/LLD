interface PaymentCategory {
    public boolean makePayment(Customer customer, Cart cart);
}
