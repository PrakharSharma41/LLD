public enum City {
    Bangalore,
    Delhi;
}
