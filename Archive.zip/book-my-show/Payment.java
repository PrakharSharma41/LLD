
public class Payment {
    int paymentId;
    PaymentController paymentController;
}
