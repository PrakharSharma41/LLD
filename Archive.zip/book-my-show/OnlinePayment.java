public class OnlinePayment implements PaymentController{

    @Override
    public boolean makePayment(int paymentId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'makePayment'");
    }
    
}
