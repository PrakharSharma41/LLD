
interface PaymentController {
    public boolean makePayment(int paymentId);
}
