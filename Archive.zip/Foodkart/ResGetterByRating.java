package Foodkart;

import java.util.List;

public class ResGetterByRating implements RestaurantGetter{

    @Override
    public List<Restaurant> getRestaurant(List<Restaurant> res) {
        return res;
    }
    
}
