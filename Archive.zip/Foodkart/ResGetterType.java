package Foodkart;

public enum ResGetterType {
    RATING,
    PRICE
}
