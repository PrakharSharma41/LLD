package Foodkart;

import java.util.List;

public class ResGetterByPrice implements RestaurantGetter{

    @Override
    public List<Restaurant> getRestaurant(List<Restaurant> res) {
        return  null;
    }
    
}
