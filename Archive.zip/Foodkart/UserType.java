package Foodkart;


enum UserType{
    CUSTOMER,
    OWNER
}