package Foodkart;
import java.util.*;

public interface RestaurantGetter {
    public List<Restaurant> getRestaurant(List<Restaurant> res);
}
