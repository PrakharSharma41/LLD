package proxyDesign;

public interface EmployeeDao {
    void create();
}
