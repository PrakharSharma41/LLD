package proxyDesign;

public class EmployeeDaoImpl implements EmployeeDao{

    @Override
    public void create() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'create'");
    }
    
}
