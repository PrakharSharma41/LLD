package solidPrinciple.solid.src.Liskov;

public class Bicycle extends Vehicle{
    
}
