package solidPrinciple.solid.src.Liskov;

public class EngineVehicle extends Vehicle{
    public boolean hasEngine(){
        return true;
    }
}
