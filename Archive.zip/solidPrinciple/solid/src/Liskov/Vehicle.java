package solidPrinciple.solid.src.Liskov;

public class Vehicle {
    public Integer getWheels(){
        return 2;
    }
}
