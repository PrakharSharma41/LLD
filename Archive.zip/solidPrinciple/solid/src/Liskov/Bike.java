package solidPrinciple.solid.src.Liskov;

public class Bike extends EngineVehicle{
    
}
