package solidPrinciple.solid.src.singleResponsibility;

public class Marker {
    String name,color;

    public Marker(String name, String color) {
        this.name = name;
        this.color = color;
    }
    
}
