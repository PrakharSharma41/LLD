package solidPrinciple.solid.src.singleResponsibility;

public class InvoiceCalculator {
    Invoice invoice;
    public int calculateTotal(){
        return 0;
    }
}
