package solidPrinciple.solid.src.InterfaceSegregation;

interface RestaurantEmployee {
    void washDishes();
    void serveCustomers();
    void cookFood();
}
