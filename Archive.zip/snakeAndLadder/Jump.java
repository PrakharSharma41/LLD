
public class Jump {
    int start,end;

    public Jump(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
