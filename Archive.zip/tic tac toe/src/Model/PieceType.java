package Model;

public enum PieceType {
    O,
    X
}