package Model;

public class PlayingPiece{
    public PieceType pieceType;

    public PlayingPiece(PieceType pieceType) {
        this.pieceType = pieceType;
    }
    
}