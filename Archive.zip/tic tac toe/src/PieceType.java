
public class PieceType {

}
