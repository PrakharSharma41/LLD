
interface Vehicle {
    public int getTankCapacity();
    public int getTyreCount();   
}
