public class Car implements Vehicle{

    @Override
    public int getTankCapacity() { return 40;
    }

    @Override
    public int getTyreCount() {
        return 4;
    }
    
}
