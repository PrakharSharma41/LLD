public class NullObjectClass implements Vehicle{

    @Override
    public int getTankCapacity() {
        return 0;
    }

    @Override
    public int getTyreCount() {
        return 0;
    }
    
}
