package observer.Observer;

public interface NotificationAlertObserver {
    public  void update();    
}
