package adapterDesign;

public class WeightMachineImpl implements WeightMachine{

    @Override
    public int getWeightInPounds() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getWeightInPounds'");
    }
    
}
