package adapterDesign;

public interface WeightMachineAdapter {
    int getWeightInKg();
}
