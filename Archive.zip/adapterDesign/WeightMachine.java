package adapterDesign;

public interface WeightMachine {
    int getWeightInPounds();   
}
