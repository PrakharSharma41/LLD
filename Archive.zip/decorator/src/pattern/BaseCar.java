package pattern;

public class BaseCar {
    public int cost(){
        return 20;
    }
}
