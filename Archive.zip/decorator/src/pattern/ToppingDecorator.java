package pattern;

public abstract class ToppingDecorator extends BasePizza{    
}
