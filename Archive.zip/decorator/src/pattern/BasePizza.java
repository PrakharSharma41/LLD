package pattern;

public abstract class BasePizza {
    public abstract int cost();    
}
