package bridge;

public interface BreatheImplementor {
    public void breatheProcess();
}
