package bridge;

public class WaterBreathe implements BreatheImplementor{

    @Override
    public void breatheProcess() {
        // water breathe process
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'breatheProcess'");
    }
    
}
