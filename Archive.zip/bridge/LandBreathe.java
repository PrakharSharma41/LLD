package bridge;

public class LandBreathe implements BreatheImplementor{

    @Override
    public void breatheProcess() {
        // land breathe process
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'breatheProcess'");
    }
    
}
