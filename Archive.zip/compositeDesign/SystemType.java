package compositeDesign;

public enum SystemType {
    File,
    Directory
}
