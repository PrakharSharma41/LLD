package strategy;

import java.util.Map;

import enums.TaskStatus;
import models.Task;
import models.User;

public class TaskFilterStrategyImpl extends TaskFilterStrategy{

    Map<Task,Integer>taskMap;
    public TaskFilterStrategyImpl(Map<Task,Integer>taskMap){
        this.taskMap=taskMap;
    }
    @Override
    public void logAllTask(TaskStatus taskStatus) {
        for(Task task:taskMap.keySet()){
            if(task.getTaskStatus()==taskStatus){
                System.out.println(task);
            }
        }
    }
    @Override
    public void getActivityLog(Integer startTime, Integer endTime){
        for(Task task:taskMap.keySet()){
            if(task.getDate()>=startTime&&task.getDeadline()<=endTime){
                System.out.println(task);
            }
        }
    };    
}
