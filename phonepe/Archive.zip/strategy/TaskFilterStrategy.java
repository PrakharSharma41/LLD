package strategy;

import java.util.List;

import enums.TaskStatus;
import models.Task;
import models.User;

public abstract class TaskFilterStrategy {
    public abstract void logAllTask(TaskStatus taskStatus);
    public abstract void getActivityLog(Integer startTime,Integer endTime);
}
