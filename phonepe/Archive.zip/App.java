import enums.TaskStatus;
import models.User;
import service.TaskService;
import service.UserService;

public class App {
    public static void main(String[] args) {
        UserService userService=new UserService();
        TaskService taskService=new TaskService(userService);
        User user=userService.createUser("user1");
        taskService.createTask("user1", "task1", 1, 2);
        taskService.createTask("user1", "task2", 1, 2);
        taskService.createTask("user1", "task3", 1, 2);
        taskService.completeTask("task1");
        taskService.removeTask("task2");
        System.out.println("listing all tasks for user");
        taskService.showAllTaskForUser("user1");
        System.out.println("applying filter criteria");
        taskService.listTask("user1",TaskStatus.COMPLETED);
        System.out.println("below is the activity log");
        taskService.getActivityLog("user1", 1, 5);
    }
}
