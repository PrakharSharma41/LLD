package enums;

public enum TaskStatus {
    CREATED,
    COMPLETED,
    SPILLED,
    REMOVED
}
